import { chromium } from "playwright";
import { MongoMemoryReplSet } from "mongodb-memory-server";
import mongoose from "mongoose";
import bcrypt from "bcryptjs";
import fs from "node:fs/promises";
import assert from "node:assert/strict";
import { createApp } from "../server/src/app.js";
import { User, Product } from "../server/src/models.js";
import { catalog } from "../server/src/catalog.js";
const mongo = await MongoMemoryReplSet.create({ replSet: { count: 1 } });
await mongoose.connect(mongo.getUri());
await Product.insertMany(catalog);
await User.create({
  name: "Store Admin",
  email: "admin@example.test",
  password: await bcrypt.hash("Test-only-password-123", 4),
  role: "admin",
});
const server = createApp({
  jwtSecret: "test-secret-only-abcdefghijklmnopqrstuvwxyz",
  demo: true,
  clientUrl: "http://127.0.0.1:5000",
}).listen(5000);
const browser = await chromium.launch({
  headless: true,
  args: ["--no-sandbox"],
});
const page = await browser.newPage({ viewport: { width: 1280, height: 900 } });
const errors = [];
page.on("pageerror", (e) => errors.push(e.message));
await fs.mkdir("test-results", { recursive: true });
const base = "http://127.0.0.1:5000";
async function go(path) {
  await page.goto(base + path);
  await page.waitForLoadState("networkidle");
}
async function snap(name) {
  await page.locator("footer").scrollIntoViewIfNeeded();
  await page.waitForFunction(() =>
    [...document.images].every((i) => i.complete),
  );
  assert.ok(
    await page.evaluate(() =>
      [...document.images].every((i) => i.naturalWidth > 0),
    ),
    name + " has a broken image",
  );
  await page.evaluate(() => scrollTo(0, 0));
  await page.screenshot({ path: `test-results/${name}.png`, fullPage: true });
  assert.ok(
    await page.evaluate(
      () => document.documentElement.scrollWidth <= innerWidth,
    ),
    name + " has horizontal overflow",
  );
}
try {
  await go("/");
  await page
    .getByText("Airwave Pro Wireless Headphones", { exact: true })
    .waitFor();
  assert.equal(await page.locator(".product-card").count(), 8);
  await snap("desktop-home");
  await page
    .getByRole("textbox", { name: "Search products" })
    .fill("Headphones");
  await page.getByRole("button", { name: "Submit search" }).click();
  await page.waitForURL(/search=Headphones/);
  await page.waitForFunction(
    () => document.querySelectorAll(".product-card").length === 1,
  );
  assert.equal(await page.locator(".product-card").count(), 1);
  await page.locator(".product-name").first().click();
  await page
    .getByRole("button", { name: "Add to cart", exact: true })
    .waitFor();
  const productPath = new URL(page.url()).pathname;
  await snap("desktop-product");
  await page.getByRole("button", { name: "Add to cart", exact: true }).click();
  await go("/cart");
  await page.getByRole("button", { name: /Increase/ }).click();
  assert.equal(await page.locator(".qty span").textContent(), "2");
  await snap("desktop-cart");
  await page.getByRole("link", { name: "Place order" }).click();
  await page.getByRole("link", { name: "Sign in", exact: true }).click();
  await page
    .getByRole("button", { name: "New here? Create an account" })
    .click();
  await page.getByLabel("Full name").fill("Demo Customer");
  await page.getByLabel("Email address").fill("customer@example.test");
  await page
    .getByLabel("Password", { exact: true })
    .fill("Test-only-password-123");
  await page
    .getByRole("button", { name: "Create account", exact: true })
    .click();
  await page.waitForURL("**/checkout");
  await page.getByLabel("Mobile number").fill("9876543210");
  await page.getByLabel("Address", { exact: true }).fill("123 Demo Street");
  await page.getByLabel("City", { exact: true }).fill("Patna");
  await page.getByLabel("State", { exact: true }).fill("Bihar");
  await page.getByLabel("PIN code").fill("800001");
  await snap("desktop-checkout");
  await page
    .getByRole("button", { name: "Create demo order (no charge)" })
    .click();
  await page.waitForURL("**/orders?success=1");
  await page.getByText("Order confirmed. You can track it below.").waitFor();
  await snap("desktop-orders");
  await go(productPath);
  await page
    .getByLabel("Your review")
    .fill("Comfortable sound and a clean everyday design.");
  await page.getByRole("button", { name: "Submit review" }).click();
  await page
    .getByText("Comfortable sound and a clean everyday design.")
    .waitFor();
  await page.getByRole("button", { name: "Sign out", exact: true }).click();
  await go("/auth");
  await snap("desktop-auth");
  await page.getByLabel("Email address").fill("admin@example.test");
  await page
    .getByLabel("Password", { exact: true })
    .fill("Test-only-password-123");
  await page.getByRole("button", { name: "Sign in", exact: true }).click();
  await go("/admin");
  await page.getByRole("button", { name: "Mark shipped" }).click();
  await page.getByRole("button", { name: "Mark delivered" }).waitFor();
  await page.getByRole("button", { name: "Mark delivered" }).click();
  await page.getByText("delivered", { exact: true }).waitFor();
  await snap("desktop-admin");
  await page.getByRole("button", { name: "Products", exact: true }).click();
  await page.getByRole("button", { name: "Add product" }).click();
  await page.getByLabel("Name", { exact: true }).fill("Browser Test Product");
  await page.getByLabel("Price (INR)", { exact: true }).fill("1000");
  await page.getByLabel("Original price (INR)", { exact: true }).fill("1500");
  await page
    .getByLabel("Description")
    .fill("A browser-created test product for the integration flow.");
  await page
    .getByLabel("Image URLs (one per line)")
    .fill("/images/headphones.jpg");
  await page.getByRole("button", { name: "Save product" }).click();
  await page.getByText("Browser Test Product", { exact: true }).waitFor();
  const card = page
    .locator(".admin-product")
    .filter({ hasText: "Browser Test Product" });
  await card.getByRole("button", { name: "Edit", exact: true }).click();
  await page.getByLabel("Stock", { exact: true }).fill("7");
  await page.getByRole("button", { name: "Save product" }).click();
  await card.getByText("₹1,000 · 7 in stock", { exact: true }).waitFor();
  page.once("dialog", (d) => d.accept());
  await card
    .getByRole("button", { name: "Delete Browser Test Product" })
    .click();
  await page.getByText("Product removed.", { exact: true }).waitFor();
  for (const width of [320, 390, 1280]) {
    await page.setViewportSize({ width, height: 900 });
    await go("/admin");
    await snap(`${width}-admin`);
    await page.getByRole("button", { name: "Products", exact: true }).click();
    await page.getByRole("button", { name: "Add product" }).click();
    await snap(`${width}-admin-form`);
    await page.getByRole("button", { name: "Sign out", exact: true }).click();
    await go("/auth");
    await snap(`${width}-auth`);
    await page
      .getByRole("button", { name: "New here? Create an account" })
      .click();
    await snap(`${width}-signup`);
    await page
      .getByRole("button", { name: "Already have an account? Sign in" })
      .click();
    await page.getByLabel("Email address").fill("customer@example.test");
    await page
      .getByLabel("Password", { exact: true })
      .fill("Test-only-password-123");
    await page.getByRole("button", { name: "Sign in", exact: true }).click();
    await page.waitForURL(base + "/");
    for (const [name, path] of [
      ["home", "/"],
      ["product", productPath],
      ["orders", "/orders"],
    ]) {
      await go(path);
      if (name === "home")
        await page.locator(".product-card").first().waitFor();
      if (name === "orders")
        await page
          .getByText("Demo order · No payment or actual shipment")
          .waitFor();
      await snap(`${width}-${name}`);
    }
    await go(productPath);
    await page
      .getByRole("button", { name: "Add to cart", exact: true })
      .click();
    await go("/cart");
    await snap(`${width}-cart`);
    await go("/checkout");
    await snap(`${width}-checkout`);
    await page.getByRole("button", { name: "Sign out", exact: true }).click();
    await go("/auth");
    await page.getByLabel("Email address").fill("admin@example.test");
    await page
      .getByLabel("Password", { exact: true })
      .fill("Test-only-password-123");
    await page.getByRole("button", { name: "Sign in", exact: true }).click();
    await page.waitForURL(base + "/");
  }
  assert.deepEqual(errors, []);
  console.log(
    "PASS: browser search, detail, cart quantity, signup, checkout, order, review, admin tracking, product CRUD; responsive routes at 320/390/1280, no page errors or overflow.",
  );
} finally {
  await browser.close();
  await new Promise((r) => server.close(r));
  await mongoose.disconnect();
  await mongo.stop();
}
