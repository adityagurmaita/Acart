import { test, before, after } from "node:test";
import assert from "node:assert/strict";
import { MongoMemoryReplSet } from "mongodb-memory-server";
import mongoose from "mongoose";
import request from "supertest";
import bcrypt from "bcryptjs";
import { createApp } from "../src/app.js";
import { User, Product, Order } from "../src/models.js";
import { catalog } from "../src/catalog.js";
let mongo, app, customer, admin, product, order;
const address = {
  name: "Test Customer",
  phone: "9876543210",
  line: "123 Demo Street",
  city: "Patna",
  state: "Bihar",
  pincode: "800001",
};
before(async () => {
  mongo = await MongoMemoryReplSet.create({ replSet: { count: 1 } });
  await mongoose.connect(mongo.getUri());
  await Product.insertMany(catalog);
  product = await Product.findOne();
  await User.create({
    name: "Test Admin",
    email: "admin@example.test",
    password: await bcrypt.hash("Test-only-password-123", 4),
    role: "admin",
  });
  app = createApp({
    jwtSecret: "test-secret-only-abcdefghijklmnopqrstuvwxyz",
    demo: true,
  });
  customer = request.agent(app);
  admin = request.agent(app);
});
after(async () => {
  await mongoose.disconnect();
  await mongo.stop();
});
test("signup is validated, role injection ignored, cookie is HTTP-only", async () => {
  await customer
    .post("/api/auth/signup")
    .send({ name: "A", email: "bad", password: "short" })
    .expect(400);
  const r = await customer
    .post("/api/auth/signup")
    .send({
      name: "Test Customer",
      email: "buyer@example.test",
      password: "Test-only-password-123",
      role: "admin",
    })
    .expect(201);
  assert.equal(r.body.role, "customer");
  assert.ok(r.headers["set-cookie"][0].includes("HttpOnly"));
  await customer.get("/api/auth/me").expect(200);
  await customer
    .post("/api/auth/signup")
    .send({
      name: "Other",
      email: "buyer@example.test",
      password: "Test-only-password-123",
    })
    .expect(409);
});
test("login rejects invalid credentials and logs admin in", async () => {
  await admin
    .post("/api/auth/login")
    .send({ email: "admin@example.test", password: "wrong" })
    .expect(401);
  await admin
    .post("/api/auth/login")
    .send({ email: "admin@example.test", password: "Test-only-password-123" })
    .expect(200);
});
test("catalog supports search, escaped regex, category and sort", async () => {
  const r = await customer.get(
    "/api/products?search=Headphones&category=Audio",
  );
  assert.equal(r.body.length, 1);
  await customer.get("/api/products?search=%5B").expect(200);
  const sorted = await customer.get("/api/products?sort=price_asc");
  assert.ok(sorted.body[0].price <= sorted.body[1].price);
  await customer.get("/api/products/bad-id").expect(400);
});
test("reviews are validated and duplicate reviews prevented", async () => {
  await customer
    .post(`/api/products/${product.id}/reviews`)
    .send({ rating: 6, comment: "Test review" })
    .expect(400);
  await customer
    .post(`/api/products/${product.id}/reviews`)
    .send({ rating: 5, comment: "Comfortable and great for work." })
    .expect(201);
  await customer
    .post(`/api/products/${product.id}/reviews`)
    .send({ rating: 4, comment: "Duplicate review" })
    .expect(409);
});
test("auth and admin boundaries cannot be bypassed", async () => {
  await request(app).get("/api/admin/orders").expect(401);
  await customer.get("/api/admin/orders").expect(403);
  await customer.post("/api/admin/products").send(catalog[0]).expect(403);
  await customer
    .post("/api/auth/logout")
    .set("Origin", "https://attacker.invalid")
    .expect(403);
});
test("server computes totals, stores order, deducts stock", async () => {
  const r = await customer
    .post("/api/orders")
    .send({
      items: [{ product: product.id, quantity: 2 }],
      address,
      paymentMethod: "demo",
      total: 1,
    })
    .expect(201);
  order = r.body.order;
  assert.equal(order.total, product.price * 2);
  assert.equal(order.paymentStatus, "paid");
  assert.equal((await Product.findById(product.id)).stock, product.stock - 2);
  const hist = await customer.get("/api/orders");
  assert.equal(hist.body.length, 1);
});
test("invalid quantity, duplicate items and stock shortage rejected", async () => {
  for (const items of [
    [{ product: product.id, quantity: 0 }],
    [
      { product: product.id, quantity: 1 },
      { product: product.id, quantity: 1 },
    ],
    [{ product: product.id, quantity: 99 }],
  ])
    assert.ok(
      (
        await customer
          .post("/api/orders")
          .send({ items, address, paymentMethod: "demo" })
      ).status >= 400,
    );
});
test("customer can only access own orders", async () => {
  const other = request.agent(app);
  await other.post("/api/auth/signup").send({
    name: "Other Customer",
    email: "other@example.test",
    password: "Test-only-password-123",
  });
  assert.equal((await other.get("/api/orders")).body.length, 0);
  await other
    .post(`/api/orders/${order._id}/verify`)
    .send({
      razorpay_order_id: "x",
      razorpay_payment_id: "y",
      razorpay_signature: "z",
    })
    .expect(400);
});
test("admin sees order and updates status one step at a time", async () => {
  assert.equal((await admin.get("/api/admin/orders")).body.length, 1);
  await admin
    .patch(`/api/admin/orders/${order._id}`)
    .send({ status: "delivered" })
    .expect(409);
  await admin
    .patch(`/api/admin/orders/${order._id}`)
    .send({ status: "shipped" })
    .expect(200);
  await admin
    .patch(`/api/admin/orders/${order._id}`)
    .send({ status: "delivered" })
    .expect(200);
  assert.equal((await Order.findById(order._id)).history.length, 3);
});
test("admin product create edit delete archives without losing orders", async () => {
  const { image, ...p } = catalog[0];
  const r = await admin
    .post("/api/admin/products")
    .send({ ...p, name: "Admin test product" })
    .expect(201);
  await admin
    .put("/api/admin/products/" + r.body._id)
    .send({ ...p, name: "Updated test product", price: 1000 })
    .expect(200);
  await admin.delete("/api/admin/products/" + r.body._id).expect(200);
  await customer.get("/api/products/" + r.body._id).expect(404);
  assert.equal(await Order.countDocuments(), 1);
});
test("disabled demo and absent Razorpay keys fail safely", async () => {
  const noPay = request.agent(
    createApp({
      jwtSecret: "test-secret-only-abcdefghijklmnopqrstuvwxyz",
      demo: false,
    }),
  );
  await noPay
    .post("/api/auth/login")
    .send({ email: "buyer@example.test", password: "Test-only-password-123" });
  await noPay
    .post("/api/orders")
    .send({
      items: [{ product: product.id, quantity: 1 }],
      address,
      paymentMethod: "demo",
    })
    .expect(403);
  await noPay
    .post("/api/orders")
    .send({
      items: [{ product: product.id, quantity: 1 }],
      address,
      paymentMethod: "razorpay",
    })
    .expect(503);
  await customer
    .post("/api/payments/webhook")
    .send({ event: "payment.captured" })
    .expect(503);
});
test("simultaneous purchases do not oversell", async () => {
  const p = await Product.create({ ...catalog[0], stock: 1 });
  const results = await Promise.all(
    [1, 2].map(() =>
      customer.post("/api/orders").send({
        items: [{ product: p.id, quantity: 1 }],
        address,
        paymentMethod: "demo",
      }),
    ),
  );
  assert.equal(results.filter((r) => r.status === 201).length, 1);
  assert.equal((await Product.findById(p.id)).stock, 0);
});
test("Razorpay creation, signature, capture checks and webhook idempotency", async () => {
  const crypto = await import("node:crypto");
  const secret = "gateway-test-secret";
  let amount,
    validCapture = false;
  const paymentApp = createApp({
    jwtSecret: "test-secret-only-abcdefghijklmnopqrstuvwxyz",
    demo: false,
    keyId: "rzp_test_placeholder",
    keySecret: secret,
    webhookSecret: "webhook-test-secret",
    paymentGateway: async (endpoint, options) => {
      if (endpoint === "orders") {
        amount = JSON.parse(options.body).amount;
        return { id: "order_test123", amount, currency: "INR" };
      }
      return {
        id: "pay_test123",
        order_id: "order_test123",
        amount,
        currency: "INR",
        status: validCapture ? "captured" : "authorized",
      };
    },
  });
  const buyer = request.agent(paymentApp);
  await buyer
    .post("/api/auth/login")
    .send({ email: "buyer@example.test", password: "Test-only-password-123" })
    .expect(200);
  const result = await buyer
    .post("/api/orders")
    .send({
      items: [{ product: product.id, quantity: 1 }],
      address,
      paymentMethod: "razorpay",
    })
    .expect(201);
  assert.equal(result.body.order.paymentStatus, "pending");
  assert.equal(amount, product.price * 100);
  const payload = {
    razorpay_order_id: "order_test123",
    razorpay_payment_id: "pay_test123",
    razorpay_signature: "invalid",
  };
  const verify = "/api/orders/" + result.body.order._id + "/verify";
  await buyer.post(verify).send(payload).expect(400);
  payload.razorpay_signature = crypto
    .createHmac("sha256", secret)
    .update("order_test123|pay_test123")
    .digest("hex");
  await buyer.post(verify).send(payload).expect(409);
  validCapture = true;
  await buyer.post(verify).send(payload).expect(200);
  const stock = (await Product.findById(product.id)).stock;
  await buyer.post(verify).send(payload).expect(200);
  assert.equal((await Product.findById(product.id)).stock, stock);
  const event = JSON.stringify({
    event: "payment.captured",
    payload: {
      payment: {
        entity: {
          id: "pay_test123",
          order_id: "order_test123",
          amount,
          currency: "INR",
        },
      },
    },
  });
  const signature = crypto
    .createHmac("sha256", "webhook-test-secret")
    .update(event)
    .digest("hex");
  await request(paymentApp)
    .post("/api/payments/webhook")
    .set("Content-Type", "application/json")
    .set("x-razorpay-signature", "bad")
    .send(event)
    .expect(400);
  await request(paymentApp)
    .post("/api/payments/webhook")
    .set("Content-Type", "application/json")
    .set("x-razorpay-signature", signature)
    .send(event)
    .expect(200);
  assert.equal((await Product.findById(product.id)).stock, stock);
});
