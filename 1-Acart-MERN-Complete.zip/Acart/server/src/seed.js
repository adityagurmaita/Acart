import "dotenv/config";
import mongoose from "mongoose";
import bcrypt from "bcryptjs";
import { User, Product } from "./models.js";
import { catalog } from "./catalog.js";
if (
  !process.env.MONGODB_URI ||
  !process.env.ADMIN_PASSWORD ||
  process.env.ADMIN_PASSWORD.length < 10
)
  throw new Error(
    "Set MONGODB_URI and ADMIN_PASSWORD (10+ characters) in server/.env first.",
  );
await mongoose.connect(process.env.MONGODB_URI);
if ((await Product.countDocuments()) === 0) await Product.insertMany(catalog);
const email = (process.env.ADMIN_EMAIL || "admin@acart.demo").toLowerCase();
if (!(await User.exists({ email })))
  await User.create({
    name: "Store admin",
    email,
    password: await bcrypt.hash(process.env.ADMIN_PASSWORD, 12),
    role: "admin",
  });
console.log("Seed complete. Existing data was preserved. Admin email:", email);
await mongoose.disconnect();
