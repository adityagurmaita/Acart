import "dotenv/config";
import mongoose from "mongoose";
import { createApp } from "./app.js";
if (!process.env.MONGODB_URI) throw new Error("Set MONGODB_URI in server/.env");
await mongoose.connect(process.env.MONGODB_URI);
const server = createApp().listen(process.env.PORT || 5000, () =>
  console.log("Acart API ready on port", process.env.PORT || 5000),
);
const stop = () =>
  server.close(async () => {
    await mongoose.disconnect();
    process.exit(0);
  });
process.on("SIGTERM", stop);
process.on("SIGINT", stop);
