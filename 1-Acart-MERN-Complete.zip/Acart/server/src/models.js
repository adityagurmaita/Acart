import mongoose from "mongoose";
const { Schema, model } = mongoose;
const userSchema = new Schema(
  {
    name: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true, select: false },
    role: { type: String, enum: ["customer", "admin"], default: "customer" },
  },
  { timestamps: true },
);
const reviewSchema = new Schema(
  {
    user: { type: Schema.Types.ObjectId, ref: "User" },
    name: String,
    rating: { type: Number, min: 1, max: 5 },
    comment: String,
  },
  { timestamps: true },
);
const productSchema = new Schema(
  {
    name: { type: String, required: true },
    brand: String,
    category: { type: String, required: true },
    description: String,
    images: [String],
    price: { type: Number, required: true, min: 1 },
    originalPrice: Number,
    stock: { type: Number, min: 0, required: true },
    features: [String],
    reviews: [reviewSchema],
    archived: { type: Boolean, default: false },
  },
  { timestamps: true },
);
const orderSchema = new Schema(
  {
    user: { type: Schema.Types.ObjectId, ref: "User", required: true },
    items: [
      {
        product: Schema.Types.ObjectId,
        name: String,
        image: String,
        price: Number,
        quantity: Number,
      },
    ],
    address: {
      name: String,
      phone: String,
      line: String,
      city: String,
      state: String,
      pincode: String,
    },
    subtotal: Number,
    shipping: Number,
    total: Number,
    paymentMethod: { type: String, enum: ["demo", "razorpay"] },
    paymentStatus: {
      type: String,
      enum: ["pending", "paid"],
      default: "pending",
    },
    status: {
      type: String,
      enum: ["placed", "shipped", "delivered"],
      default: "placed",
    },
    razorpayOrderId: { type: String, index: true },
    razorpayPaymentId: String,
    history: [{ status: String, at: { type: Date, default: Date.now } }],
  },
  { timestamps: true },
);
export const User = model("User", userSchema);
export const Product = model("Product", productSchema);
export const Order = model("Order", orderSchema);
