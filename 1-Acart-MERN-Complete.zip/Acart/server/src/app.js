import express from "express";
import cors from "cors";
import helmet from "helmet";
import cookieParser from "cookie-parser";
import rateLimit from "express-rate-limit";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import crypto from "node:crypto";
import mongoose from "mongoose";
import { z } from "zod";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { User, Product, Order } from "./models.js";
export function createApp(config = {}) {
  const cfg = {
    jwtSecret: process.env.JWT_SECRET,
    clientUrl: process.env.CLIENT_URL || "http://localhost:5173",
    demo: process.env.ENABLE_DEMO_PAYMENTS === "true",
    keyId: process.env.RAZORPAY_KEY_ID,
    keySecret: process.env.RAZORPAY_KEY_SECRET,
    webhookSecret: process.env.RAZORPAY_WEBHOOK_SECRET,
    ...config,
  };
  if (!cfg.jwtSecret || cfg.jwtSecret.length < 32)
    throw new Error("JWT_SECRET must contain at least 32 characters.");
  if (cfg.demo && cfg.keyId?.startsWith("rzp_live_"))
    throw new Error("Disable demo payments before using live Razorpay keys.");
  const app = express();
  app.disable("x-powered-by");
  app.set("trust proxy", 1);
  app.use(
    helmet({
      contentSecurityPolicy: {
        directives: {
          defaultSrc: ["'self'"],
          scriptSrc: ["'self'", "https://checkout.razorpay.com"],
          frameSrc: [
            "https://api.razorpay.com",
            "https://checkout.razorpay.com",
          ],
          connectSrc: ["'self'", "https://api.razorpay.com"],
          imgSrc: ["'self'", "data:", "https:"],
          styleSrc: ["'self'", "'unsafe-inline'"],
        },
      },
    }),
  );
  app.use(cors({ origin: cfg.clientUrl, credentials: true }));
  const wrap = (fn) => (req, res, next) =>
    Promise.resolve(fn(req, res, next)).catch(next);
  const equal = (a, b) =>
    typeof a === "string" &&
    typeof b === "string" &&
    a.length === b.length &&
    crypto.timingSafeEqual(Buffer.from(a), Buffer.from(b));
  const fail = (status, message) =>
    Object.assign(new Error(message), { status });
  const auth = wrap(async (req, res, next) => {
    try {
      const payload = jwt.verify(req.cookies.session, cfg.jwtSecret);
      req.user = await User.findById(payload.sub);
      if (!req.user) throw Error();
    } catch {
      throw fail(401, "Please sign in to continue.");
    }
    next();
  });
  const admin = (req, res, next) =>
    req.user.role === "admin"
      ? next()
      : next(fail(403, "Admin access required."));
  const safeUser = (u) => ({
    id: u.id,
    name: u.name,
    email: u.email,
    role: u.role,
  });
  const session = (res, u) =>
    res.cookie(
      "session",
      jwt.sign({ sub: u.id }, cfg.jwtSecret, { expiresIn: "7d" }),
      {
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
        sameSite: "lax",
        maxAge: 604800000,
        path: "/",
      },
    );
  const gateway =
    cfg.paymentGateway ||
    (async (endpoint, options = {}) => {
      const r = await fetch(`https://api.razorpay.com/v1/${endpoint}`, {
        ...options,
        signal: AbortSignal.timeout(15000),
        headers: {
          Authorization:
            "Basic " +
            Buffer.from(`${cfg.keyId}:${cfg.keySecret}`).toString("base64"),
          "Content-Type": "application/json",
        },
      });
      const d = await r.json();
      if (!r.ok)
        throw fail(502, "Payment gateway unavailable. Please try again.");
      return d;
    });
  const settle = async (orderId, paymentId) =>
    mongoose.connection.transaction(async (s) => {
      const o = await Order.findById(orderId).session(s);
      if (!o) throw fail(404, "Order not found.");
      if (o.paymentStatus === "paid") return o;
      for (const i of o.items) {
        const p = await Product.findOneAndUpdate(
          { _id: i.product, archived: false, stock: { $gte: i.quantity } },
          { $inc: { stock: -i.quantity } },
          { session: s, new: true },
        );
        if (!p)
          throw fail(
            409,
            "One item is no longer available. Contact support if your payment was captured.",
          );
      }
      o.paymentStatus = "paid";
      o.razorpayPaymentId = paymentId;
      o.history = [{ status: "placed", at: new Date() }];
      await o.save({ session: s });
      return o;
    });
  app.post(
    "/api/payments/webhook",
    express.raw({ type: "application/json", limit: "100kb" }),
    wrap(async (req, res) => {
      if (!cfg.webhookSecret) throw fail(503, "Webhook is not configured.");
      const sig = crypto
        .createHmac("sha256", cfg.webhookSecret)
        .update(req.body)
        .digest("hex");
      if (!equal(sig, req.headers["x-razorpay-signature"]))
        throw fail(400, "Invalid webhook signature.");
      const event = JSON.parse(req.body);
      if (event.event === "payment.captured") {
        const p = event.payload.payment.entity;
        const o = await Order.findOne({ razorpayOrderId: p.order_id });
        if (o && p.amount === o.total * 100 && p.currency === "INR")
          await settle(o.id, p.id);
      }
      res.json({ ok: true });
    }),
  );
  app.use(express.json({ limit: "100kb" }));
  app.use(cookieParser());
  app.use(
    "/api",
    rateLimit({
      windowMs: 60000,
      limit: 180,
      standardHeaders: "draft-8",
      legacyHeaders: false,
    }),
  );
  app.use("/api", (req, res, next) => {
    if (
      !["GET", "HEAD", "OPTIONS"].includes(req.method) &&
      req.headers.origin &&
      req.headers.origin !== cfg.clientUrl
    )
      return next(fail(403, "Request origin is not allowed."));
    next();
  });
  app.get("/api/health", (_, res) =>
    res.json({
      ok: true,
      database:
        mongoose.connection.readyState === 1 ? "connected" : "unavailable",
    }),
  );
  app.get("/api/config", (_, res) =>
    res.json({ demo: cfg.demo, razorpay: !!(cfg.keyId && cfg.keySecret) }),
  );
  const loginLimit = rateLimit({
    windowMs: 900000,
    limit: 25,
    standardHeaders: "draft-8",
    legacyHeaders: false,
  });
  const signupSchema = z.object({
    name: z.string().trim().min(2).max(60),
    email: z.email().toLowerCase(),
    password: z.string().min(10).max(72),
  });
  app.post(
    "/api/auth/signup",
    loginLimit,
    wrap(async (req, res) => {
      const d = signupSchema.parse(req.body);
      if (await User.exists({ email: d.email }))
        throw fail(409, "This email already has an account.");
      const u = await User.create({
        ...d,
        password: await bcrypt.hash(d.password, 12),
      });
      session(res, u);
      res.status(201).json(safeUser(u));
    }),
  );
  app.post(
    "/api/auth/login",
    loginLimit,
    wrap(async (req, res) => {
      const d = z
        .object({
          email: z.email().toLowerCase(),
          password: z.string().max(72),
        })
        .parse(req.body);
      const u = await User.findOne({ email: d.email }).select("+password");
      if (!u || !(await bcrypt.compare(d.password, u.password)))
        throw fail(401, "Email or password is incorrect.");
      session(res, u);
      res.json(safeUser(u));
    }),
  );
  app.post("/api/auth/logout", (_, res) => {
    res.clearCookie("session", { path: "/" });
    res.json({ ok: true });
  });
  app.get("/api/auth/me", auth, (req, res) => res.json(safeUser(req.user)));
  app.get(
    "/api/products",
    wrap(async (req, res) => {
      const f = { archived: false };
      if (req.query.category)
        f.category = String(req.query.category).slice(0, 60);
      if (req.query.search) {
        const t = String(req.query.search)
          .slice(0, 100)
          .replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
        f.$or = [
          { name: { $regex: t, $options: "i" } },
          { brand: { $regex: t, $options: "i" } },
        ];
      }
      const sort = {
        price_asc: { price: 1 },
        price_desc: { price: -1 },
        newest: { createdAt: -1 },
      }[req.query.sort] || { createdAt: 1 };
      res.json(await Product.find(f).sort(sort).limit(100));
    }),
  );
  app.get(
    "/api/products/:id",
    wrap(async (req, res) => {
      const p = await Product.findOne({ _id: req.params.id, archived: false });
      if (!p) throw fail(404, "Product not found.");
      res.json(p);
    }),
  );
  app.post(
    "/api/products/:id/reviews",
    auth,
    wrap(async (req, res) => {
      const d = z
        .object({
          rating: z.number().int().min(1).max(5),
          comment: z.string().trim().min(5).max(800),
        })
        .parse(req.body);
      const p = await Product.findOneAndUpdate(
        {
          _id: req.params.id,
          archived: false,
          "reviews.user": { $ne: req.user._id },
        },
        {
          $push: { reviews: { ...d, user: req.user._id, name: req.user.name } },
        },
        { new: true },
      );
      if (!p) throw fail(409, "Product not found or you already reviewed it.");
      res.status(201).json(p);
    }),
  );
  const address = z.object({
    name: z.string().trim().min(2).max(60),
    phone: z.string().regex(/^[6-9]\d{9}$/),
    line: z.string().trim().min(5).max(200),
    city: z.string().trim().min(2).max(80),
    state: z.string().trim().min(2).max(80),
    pincode: z.string().regex(/^[1-9]\d{5}$/),
  });
  app.post(
    "/api/orders",
    auth,
    wrap(async (req, res) => {
      const d = z
        .object({
          items: z
            .array(
              z.object({
                product: z.string().regex(/^[a-f\d]{24}$/i),
                quantity: z.number().int().min(1).max(10),
              }),
            )
            .min(1)
            .max(30),
          address,
          paymentMethod: z.enum(["demo", "razorpay"]),
        })
        .parse(req.body);
      if (new Set(d.items.map((i) => i.product)).size !== d.items.length)
        throw fail(400, "Duplicate cart items.");
      if (d.paymentMethod === "demo" && !cfg.demo)
        throw fail(403, "Demo checkout is disabled.");
      if (d.paymentMethod === "razorpay" && !(cfg.keyId && cfg.keySecret))
        throw fail(503, "Razorpay is not configured.");
      const items = [];
      for (const i of d.items) {
        const p = await Product.findOne({ _id: i.product, archived: false });
        if (!p || p.stock < i.quantity)
          throw fail(
            409,
            "Some items are out of stock. Please update your cart.",
          );
        items.push({
          product: p._id,
          name: p.name,
          image: p.images[0],
          price: p.price,
          quantity: i.quantity,
        });
      }
      const subtotal = items.reduce((s, i) => s + i.price * i.quantity, 0),
        shipping = subtotal >= 1999 ? 0 : 49;
      let o = await Order.create({
        user: req.user._id,
        items,
        address: d.address,
        subtotal,
        shipping,
        total: subtotal + shipping,
        paymentMethod: d.paymentMethod,
      });
      if (d.paymentMethod === "demo") {
        o = await settle(o.id, "DEMO-NO-CHARGE");
        return res.status(201).json({ order: o });
      }
      const rp = await gateway("orders", {
        method: "POST",
        body: JSON.stringify({
          amount: o.total * 100,
          currency: "INR",
          receipt: o.id,
        }),
      });
      o.razorpayOrderId = rp.id;
      await o.save();
      res.status(201).json({ order: o, keyId: cfg.keyId, gatewayOrder: rp });
    }),
  );
  app.post(
    "/api/orders/:id/verify",
    auth,
    wrap(async (req, res) => {
      const d = z
        .object({
          razorpay_order_id: z.string(),
          razorpay_payment_id: z.string(),
          razorpay_signature: z.string(),
        })
        .parse(req.body);
      const o = await Order.findOne({
        _id: req.params.id,
        user: req.user._id,
        paymentMethod: "razorpay",
      });
      if (!o || o.razorpayOrderId !== d.razorpay_order_id)
        throw fail(400, "Payment order does not match.");
      const sig = crypto
        .createHmac("sha256", cfg.keySecret)
        .update(`${d.razorpay_order_id}|${d.razorpay_payment_id}`)
        .digest("hex");
      if (!equal(sig, d.razorpay_signature))
        throw fail(400, "Payment signature is invalid.");
      const p = await gateway(
        `payments/${encodeURIComponent(d.razorpay_payment_id)}`,
      );
      if (
        p.status !== "captured" ||
        p.order_id !== o.razorpayOrderId ||
        p.amount !== o.total * 100 ||
        p.currency !== "INR"
      )
        throw fail(
          409,
          "Payment is not captured yet. Please check your order history shortly.",
        );
      res.json(await settle(o.id, p.id));
    }),
  );
  app.get(
    "/api/orders",
    auth,
    wrap(async (req, res) =>
      res.json(
        await Order.find({ user: req.user._id }).sort({ createdAt: -1 }),
      ),
    ),
  );
  app.get(
    "/api/admin/orders",
    auth,
    admin,
    wrap(async (_, res) =>
      res.json(
        await Order.find()
          .populate("user", "name email")
          .sort({ createdAt: -1 })
          .limit(200),
      ),
    ),
  );
  app.patch(
    "/api/admin/orders/:id",
    auth,
    admin,
    wrap(async (req, res) => {
      const { status } = z
        .object({ status: z.enum(["shipped", "delivered"]) })
        .parse(req.body);
      const o = await Order.findById(req.params.id);
      if (!o) throw fail(404, "Order not found.");
      if (o.paymentStatus !== "paid")
        throw fail(409, "An unpaid order cannot ship.");
      const expected = { placed: "shipped", shipped: "delivered" }[o.status];
      if (status !== expected)
        throw fail(409, "Order status must move one step forward.");
      const updated = await Order.findOneAndUpdate(
        { _id: o._id, status: o.status, paymentStatus: "paid" },
        { $set: { status }, $push: { history: { status, at: new Date() } } },
        { new: true },
      );
      if (!updated)
        throw fail(409, "Order was updated elsewhere. Refresh and try again.");
      res.json(updated);
    }),
  );
  const productInput = z
    .object({
      name: z.string().trim().min(3).max(100),
      brand: z.string().trim().max(40),
      category: z.enum([
        "Audio",
        "Wearables",
        "Computing",
        "Cameras",
        "Accessories",
      ]),
      description: z.string().min(15).max(2000),
      images: z
        .array(
          z
            .string()
            .refine(
              (v) =>
                /^\/images\/[a-z\d-]+\.jpg$/i.test(v) || /^https:\/\//.test(v),
              "Use HTTPS image URLs or a bundled image path.",
            ),
        )
        .min(1)
        .max(5),
      price: z.number().int().min(1).max(1000000),
      originalPrice: z.number().int().min(1).max(1000000),
      stock: z.number().int().min(0).max(100000),
      features: z.array(z.string().max(150)).max(10),
    })
    .refine((d) => d.originalPrice >= d.price, {
      message: "Original price must be at least the sale price.",
    });
  app.post(
    "/api/admin/products",
    auth,
    admin,
    wrap(async (req, res) =>
      res.status(201).json(await Product.create(productInput.parse(req.body))),
    ),
  );
  app.put(
    "/api/admin/products/:id",
    auth,
    admin,
    wrap(async (req, res) => {
      const p = await Product.findOneAndUpdate(
        { _id: req.params.id, archived: false },
        productInput.parse(req.body),
        { new: true, runValidators: true },
      );
      if (!p) throw fail(404, "Product not found.");
      res.json(p);
    }),
  );
  app.delete(
    "/api/admin/products/:id",
    auth,
    admin,
    wrap(async (req, res) => {
      const p = await Product.findByIdAndUpdate(
        req.params.id,
        { archived: true },
        { new: true },
      );
      if (!p) throw fail(404, "Product not found.");
      res.json({ ok: true });
    }),
  );
  const dist = path.resolve(
    path.dirname(fileURLToPath(import.meta.url)),
    "../../client/dist",
  );
  app.use(express.static(dist));
  app.get("/{*path}", (req, res, next) => {
    if (req.path.startsWith("/api/"))
      return next(fail(404, "API route not found."));
    res.sendFile(path.join(dist, "index.html"));
  });
  app.use((err, req, res, next) => {
    if (err instanceof z.ZodError)
      return res.status(400).json({
        message: err.issues
          .map((i) => `${i.path.join(".")}: ${i.message}`)
          .join("; "),
      });
    if (err.name === "CastError")
      return res.status(400).json({ message: "Invalid identifier." });
    if (err.code === 11000)
      return res.status(409).json({ message: "This record already exists." });
    if (!err.status) console.error(err.message);
    res.status(err.status || 500).json({
      message: err.status
        ? err.message
        : "Something went wrong. Please try again.",
    });
  });
  return app;
}
