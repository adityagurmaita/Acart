import React, { useState, useEffect, createContext, useContext } from "react";
import {
  Routes,
  Route,
  Link,
  useNavigate,
  useSearchParams,
  useParams,
} from "react-router-dom";
import {
  Search,
  ShoppingCart,
  UserRound,
  ChevronDown,
  Package,
  ShieldCheck,
  Truck,
  ArrowRight,
  Headphones,
  Watch,
  Keyboard,
  Camera,
  Plug,
  Plus,
  Minus,
  Trash2,
  LogOut,
  Check,
  Star,
  LayoutDashboard,
  Menu,
  X,
} from "lucide-react";
import { api, money, rating } from "../api";
import { useStore, categories } from "../store";
import { Empty, ErrorBox, Image, Summary, Gate } from "../components/shared";
export default function Orders() {
  return (
    <Gate>
      <OrderList />
    </Gate>
  );
}

function OrderList() {
  const [orders, setOrders] = useState(null),
    [error, setError] = useState(""),
    [params] = useSearchParams();
  useEffect(() => {
    api("/orders")
      .then(setOrders)
      .catch((e) => setError(e.message));
  }, []);
  return (
    <div className="container">
      <div className="page-heading">
        <h1>My orders</h1>
        <p>Your purchases, from checkout to delivery.</p>
      </div>
      {params.get("success") && (
        <div className="success">
          <Check />
          Order confirmed. You can track it below.
        </div>
      )}
      <ErrorBox message={error} />
      {orders === null && !error ? (
        <p>Loading orders...</p>
      ) : orders?.length ? (
        orders.map((o) => (
          <section className="panel order-card" key={o._id}>
            <div className="order-head">
              <div>
                <strong>Order #{o._id.slice(-8).toUpperCase()}</strong>
                <small>{new Date(o.createdAt).toLocaleString("en-IN")}</small>
              </div>
              <span
                className={
                  "status " + (o.paymentStatus === "paid" ? "" : "pending")
                }
              >
                {o.paymentStatus === "paid" ? o.status : "Payment pending"}
              </span>
            </div>
            {o.items.map((i) => (
              <div className="order-product" key={i.product}>
                <Image src={i.image} name={i.name} />
                <div>
                  <strong>{i.name}</strong>
                  <p>
                    Qty: {i.quantity} · {money(i.price)}
                  </p>
                </div>
              </div>
            ))}
            {o.paymentStatus === "paid" && (
              <div className="tracking">
                {["placed", "shipped", "delivered"].map((s, i) => (
                  <div
                    key={s}
                    className={
                      i <= ["placed", "shipped", "delivered"].indexOf(o.status)
                        ? "done"
                        : ""
                    }
                  >
                    <span>
                      <Check size={15} />
                    </span>
                    <strong>{s}</strong>
                    <small>
                      {o.history.find((h) => h.status === s)
                        ? new Date(
                            o.history.find((h) => h.status === s).at,
                          ).toLocaleDateString("en-IN")
                        : "Awaiting update"}
                    </small>
                  </div>
                ))}
              </div>
            )}
            <div className="order-foot">
              <div>
                <strong>{o.address.name}</strong>
                <p>
                  {o.address.line}, {o.address.city}, {o.address.state} -{" "}
                  {o.address.pincode}
                </p>
                <small>
                  {o.paymentMethod === "demo"
                    ? "Demo order · No payment or actual shipment"
                    : "Razorpay · " + o.paymentStatus}
                </small>
              </div>
              <strong>{money(o.total)}</strong>
            </div>
          </section>
        ))
      ) : (
        !error && (
          <Empty
            title="No orders yet"
            detail="Your next upgrade is waiting in the store."
          />
        )
      )}
    </div>
  );
}
