import React, { useState, useEffect, createContext, useContext } from "react";
import {
  Routes,
  Route,
  Link,
  useNavigate,
  useSearchParams,
  useParams,
} from "react-router-dom";
import {
  Search,
  ShoppingCart,
  UserRound,
  ChevronDown,
  Package,
  ShieldCheck,
  Truck,
  ArrowRight,
  Headphones,
  Watch,
  Keyboard,
  Camera,
  Plug,
  Plus,
  Minus,
  Trash2,
  LogOut,
  Check,
  Star,
  LayoutDashboard,
  Menu,
  X,
} from "lucide-react";
import { api, money, rating } from "../api";
import { useStore, categories } from "../store";
import { Empty, ErrorBox, Image, Summary, Gate } from "../components/shared";
export default function Cart() {
  const { cart, setCart } = useStore();
  const total = cart.reduce((s, i) => s + i.price * i.quantity, 0);
  if (!cart.length)
    return (
      <div className="container">
        <Empty
          title="Your cart is waiting"
          detail="Find something you'll love and add it here."
        />
      </div>
    );
  return (
    <div className="container">
      <div className="page-heading">
        <h1>
          Your cart <span>({cart.length} items)</span>
        </h1>
        <p>One step closer to your next upgrade.</p>
      </div>
      <div className="two-col">
        <section className="panel cart-list">
          {cart.map((i) => (
            <div className="cart-item" key={i._id}>
              <Link to={"/product/" + i._id}>
                <Image src={i.images[0]} name={i.name} />
              </Link>
              <div className="cart-info">
                <Link to={"/product/" + i._id}>{i.name}</Link>
                <p className="brand">{i.brand}</p>
                <strong>{money(i.price)}</strong>
                <div className="qty">
                  <button
                    aria-label={"Decrease " + i.name}
                    onClick={() =>
                      setCart((c) =>
                        c.map((x) =>
                          x._id === i._id
                            ? { ...x, quantity: Math.max(1, x.quantity - 1) }
                            : x,
                        ),
                      )
                    }
                  >
                    <Minus size={15} />
                  </button>
                  <span>{i.quantity}</span>
                  <button
                    aria-label={"Increase " + i.name}
                    disabled={i.quantity >= Math.min(10, i.stock)}
                    onClick={() =>
                      setCart((c) =>
                        c.map((x) =>
                          x._id === i._id
                            ? { ...x, quantity: x.quantity + 1 }
                            : x,
                        ),
                      )
                    }
                  >
                    <Plus size={15} />
                  </button>
                  <button
                    className="remove"
                    onClick={() =>
                      setCart((c) => c.filter((x) => x._id !== i._id))
                    }
                  >
                    <Trash2 size={15} />
                    Remove
                  </button>
                </div>
              </div>
              <strong className="line-total">
                {money(i.price * i.quantity)}
              </strong>
            </div>
          ))}
        </section>
        <Summary total={total} count={cart.reduce((s, i) => s + i.quantity, 0)}>
          <Link className="button orange full" to="/checkout">
            Place order <ArrowRight size={18} />
          </Link>
          <p className="safe-note">
            <ShieldCheck size={16} />
            Server verifies prices at checkout
          </p>
        </Summary>
      </div>
    </div>
  );
}
