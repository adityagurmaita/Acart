import React, { useState, useEffect, createContext, useContext } from "react";
import {
  Routes,
  Route,
  Link,
  useNavigate,
  useSearchParams,
  useParams,
} from "react-router-dom";
import {
  Search,
  ShoppingCart,
  UserRound,
  ChevronDown,
  Package,
  ShieldCheck,
  Truck,
  ArrowRight,
  Headphones,
  Watch,
  Keyboard,
  Camera,
  Plug,
  Plus,
  Minus,
  Trash2,
  LogOut,
  Check,
  Star,
  LayoutDashboard,
  Menu,
  X,
} from "lucide-react";
import { api, money, rating } from "../api";
import { useStore, categories } from "../store";
import { Empty, ErrorBox, Image, Summary, Gate } from "../components/shared";
export default function Checkout() {
  return (
    <Gate>
      <CheckoutForm />
    </Gate>
  );
}

function CheckoutForm() {
  const { user, cart, setCart, config } = useStore(),
    nav = useNavigate();
  const [error, setError] = useState(""),
    [busy, setBusy] = useState(false),
    [method, setMethod] = useState("");
  useEffect(() => {
    setMethod(config.demo ? "demo" : config.razorpay ? "razorpay" : "");
  }, [config]);
  const total = cart.reduce((s, i) => s + i.price * i.quantity, 0);
  async function submit(e) {
    e.preventDefault();
    setBusy(true);
    setError("");
    const address = Object.fromEntries(new FormData(e.target));
    try {
      const d = await api("/orders", {
        method: "POST",
        body: JSON.stringify({
          items: cart.map((i) => ({ product: i._id, quantity: i.quantity })),
          address,
          paymentMethod: method,
        }),
      });
      if (method === "demo") {
        setCart([]);
        nav("/orders?success=1");
        return;
      }
      await new Promise((resolve, reject) => {
        if (window.Razorpay) return resolve();
        const s = document.createElement("script");
        s.src = "https://checkout.razorpay.com/v1/checkout.js";
        s.onload = resolve;
        s.onerror = () =>
          reject(
            new Error(
              "Could not load Razorpay checkout. Your order remains unpaid.",
            ),
          );
        document.body.append(s);
      });
      const checkout = new window.Razorpay({
        key: d.keyId,
        amount: d.gatewayOrder.amount,
        currency: "INR",
        name: "Acart",
        description: "Store order",
        order_id: d.gatewayOrder.id,
        prefill: {
          name: user.name,
          email: user.email,
          contact: "+91" + address.phone,
        },
        handler: async (response) => {
          try {
            await api("/orders/" + d.order._id + "/verify", {
              method: "POST",
              body: JSON.stringify(response),
            });
            setCart([]);
            nav("/orders?success=1");
          } catch (err) {
            setError(err.message + " Check order history before paying again.");
          } finally {
            setBusy(false);
          }
        },
        modal: {
          ondismiss: () => {
            setBusy(false);
            setError(
              "Payment cancelled. No paid order was confirmed. Check order history before retrying.",
            );
          },
        },
        theme: { color: "#2874f0" },
      });
      checkout.on("payment.failed", () => {
        setBusy(false);
        setError("Payment failed. Check your order history before retrying.");
      });
      checkout.open();
    } catch (err) {
      setError(err.message);
      setBusy(false);
    }
  }
  if (!cart.length)
    return (
      <Empty
        title="Your cart is empty"
        detail="Add products before checkout."
      />
    );
  return (
    <div className="container">
      <div className="page-heading">
        <h1>Checkout</h1>
        <p>Delivery details and secure payment.</p>
      </div>
      <div className="two-col">
        <form className="panel checkout-form" onSubmit={submit}>
          <h2>
            <span className="step-number">1</span>Delivery address
          </h2>
          <ErrorBox message={error} />
          <div className="form-grid">
            <label>
              Full name
              <input
                name="name"
                defaultValue={user.name}
                required
                minLength={2}
                maxLength={60}
              />
            </label>
            <label>
              Mobile number
              <input
                name="phone"
                type="tel"
                inputMode="numeric"
                pattern="[6-9][0-9]{9}"
                placeholder="10-digit Indian mobile"
                required
              />
            </label>
            <label className="span2">
              Address
              <input
                name="line"
                placeholder="House, street, area"
                required
                minLength={5}
                maxLength={200}
              />
            </label>
            <label>
              City
              <input name="city" required minLength={2} />
            </label>
            <label>
              State
              <input name="state" required minLength={2} />
            </label>
            <label>
              PIN code
              <input
                name="pincode"
                inputMode="numeric"
                pattern="[1-9][0-9]{5}"
                required
              />
            </label>
          </div>
          <h2>
            <span className="step-number">2</span>Payment method
          </h2>
          {config.demo && (
            <label className="payment-option">
              <input
                type="radio"
                checked={method === "demo"}
                onChange={() => setMethod("demo")}
              />
              <span>
                <strong>Demo checkout (no charge)</strong>
                <small>
                  For project testing only. No actual payment or shipment.
                </small>
              </span>
            </label>
          )}
          {config.razorpay && (
            <label className="payment-option">
              <input
                type="radio"
                checked={method === "razorpay"}
                onChange={() => setMethod("razorpay")}
              />
              <span>
                <strong>Razorpay</strong>
                <small>
                  UPI, cards and netbanking. Mode depends on configured keys.
                </small>
              </span>
            </label>
          )}
          {!config.demo && !config.razorpay && (
            <ErrorBox message="Payments are not configured. Contact the store admin." />
          )}
          <button className="button orange full" disabled={busy || !method}>
            {busy
              ? "Processing..."
              : method === "demo"
                ? "Create demo order (no charge)"
                : "Continue to Razorpay"}{" "}
            <ArrowRight size={18} />
          </button>
        </form>
        <Summary total={total} count={cart.reduce((s, i) => s + i.quantity, 0)}>
          <div className="checkout-items">
            {cart.map((i) => (
              <div key={i._id}>
                <Image src={i.images[0]} name={i.name} />
                <span>
                  {i.name}
                  <small>Qty: {i.quantity}</small>
                </span>
              </div>
            ))}
          </div>
        </Summary>
      </div>
    </div>
  );
}
