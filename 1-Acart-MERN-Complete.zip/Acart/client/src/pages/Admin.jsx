import React, { useState, useEffect, createContext, useContext } from "react";
import {
  Routes,
  Route,
  Link,
  useNavigate,
  useSearchParams,
  useParams,
} from "react-router-dom";
import {
  Search,
  ShoppingCart,
  UserRound,
  ChevronDown,
  Package,
  ShieldCheck,
  Truck,
  ArrowRight,
  Headphones,
  Watch,
  Keyboard,
  Camera,
  Plug,
  Plus,
  Minus,
  Trash2,
  LogOut,
  Check,
  Star,
  LayoutDashboard,
  Menu,
  X,
} from "lucide-react";
import { api, money, rating } from "../api";
import { useStore, categories } from "../store";
import { Empty, ErrorBox, Image, Summary, Gate } from "../components/shared";
export default function Admin() {
  return (
    <Gate admin>
      <AdminDashboard />
    </Gate>
  );
}

function AdminDashboard() {
  const { setToast } = useStore();
  const [tab, setTab] = useState("orders"),
    [orders, setOrders] = useState([]),
    [products, setProducts] = useState([]),
    [loading, setLoading] = useState(true),
    [error, setError] = useState(""),
    [editing, setEditing] = useState(null),
    [busy, setBusy] = useState(false);
  const refresh = async () => {
    try {
      const [o, p] = await Promise.all([
        api("/admin/orders"),
        api("/products"),
      ]);
      setOrders(o);
      setProducts(p);
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    refresh();
  }, []);
  async function status(o) {
    setError("");
    try {
      await api("/admin/orders/" + o._id, {
        method: "PATCH",
        body: JSON.stringify({
          status: o.status === "placed" ? "shipped" : "delivered",
        }),
      });
      await refresh();
      setToast("Order status updated.");
    } catch (e) {
      setError(e.message);
    }
  }
  async function save(e) {
    e.preventDefault();
    setBusy(true);
    setError("");
    const f = Object.fromEntries(new FormData(e.target));
    const d = {
      ...f,
      price: Number(f.price),
      originalPrice: Number(f.originalPrice),
      stock: Number(f.stock),
      images: f.images
        .split("\n")
        .map((s) => s.trim())
        .filter(Boolean),
      features: f.features
        .split("\n")
        .map((s) => s.trim())
        .filter(Boolean),
    };
    try {
      await api("/admin/products" + (editing._id ? "/" + editing._id : ""), {
        method: editing._id ? "PUT" : "POST",
        body: JSON.stringify(d),
      });
      setEditing(null);
      await refresh();
      setToast("Product saved.");
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  }
  async function remove(p) {
    if (
      !confirm(
        "Remove " +
          p.name +
          " from the store? Existing orders will be preserved.",
      )
    )
      return;
    try {
      await api("/admin/products/" + p._id, { method: "DELETE" });
      await refresh();
      setToast("Product removed.");
    } catch (e) {
      setError(e.message);
    }
  }
  return (
    <div className="container">
      <div className="page-heading">
        <span className="eyebrow dark">STORE MANAGEMENT</span>
        <h1>Admin dashboard</h1>
        <p>Keep your products fresh and your orders moving.</p>
      </div>
      <div className="stats">
        <div className="panel">
          <span>Total orders</span>
          <strong>{orders.length}</strong>
        </div>
        <div className="panel">
          <span>Paid order value</span>
          <strong>
            {money(
              orders
                .filter((o) => o.paymentStatus === "paid")
                .reduce((s, o) => s + o.total, 0),
            )}
          </strong>
          <small>Includes demo orders</small>
        </div>
        <div className="panel">
          <span>Active products</span>
          <strong>{products.length}</strong>
        </div>
        <div className="panel">
          <span>Ready to ship</span>
          <strong>
            {
              orders.filter(
                (o) => o.status === "placed" && o.paymentStatus === "paid",
              ).length
            }
          </strong>
        </div>
      </div>
      <div className="admin-tabs">
        <button
          className={tab === "orders" ? "active" : ""}
          onClick={() => {
            setTab("orders");
            setEditing(null);
          }}
        >
          Orders
        </button>
        <button
          className={tab === "products" ? "active" : ""}
          onClick={() => setTab("products")}
        >
          Products
        </button>
        {tab === "products" && (
          <button className="button primary" onClick={() => setEditing({})}>
            <Plus size={18} />
            Add product
          </button>
        )}
      </div>
      <ErrorBox message={error} />
      {editing && (
        <form className="panel product-form" onSubmit={save}>
          <h2>{editing._id ? "Edit product" : "Add product"}</h2>
          <div className="form-grid">
            <label>
              Name
              <input
                name="name"
                defaultValue={editing.name}
                required
                minLength={3}
              />
            </label>
            <label>
              Brand
              <input
                name="brand"
                defaultValue={editing.brand || "ACART"}
                required
              />
            </label>
            <label>
              Category
              <select name="category" defaultValue={editing.category}>
                {categories.map((c) => (
                  <option key={c}>{c}</option>
                ))}
              </select>
            </label>
            <label>
              Price (INR)
              <input
                name="price"
                type="number"
                min="1"
                step="1"
                defaultValue={editing.price}
                required
              />
            </label>
            <label>
              Original price (INR)
              <input
                name="originalPrice"
                type="number"
                min="1"
                step="1"
                defaultValue={editing.originalPrice}
                required
              />
            </label>
            <label>
              Stock
              <input
                name="stock"
                type="number"
                min="0"
                step="1"
                defaultValue={editing.stock ?? 10}
                required
              />
            </label>
            <label className="span2">
              Description
              <textarea
                name="description"
                minLength={15}
                defaultValue={editing.description}
                required
              />
            </label>
            <label className="span2">
              Image URLs (one per line)
              <textarea
                name="images"
                placeholder="https://... or /images/headphones.jpg"
                defaultValue={editing.images?.join("\n")}
                required
              />
            </label>
            <label className="span2">
              Features (one per line)
              <textarea
                name="features"
                defaultValue={editing.features?.join("\n")}
              />
            </label>
          </div>
          <div className="form-actions">
            <button className="button primary" disabled={busy}>
              {busy ? "Saving..." : "Save product"}
            </button>
            <button
              type="button"
              className="button secondary"
              onClick={() => setEditing(null)}
            >
              Cancel
            </button>
          </div>
        </form>
      )}
      {loading ? (
        <p>Loading dashboard...</p>
      ) : tab === "orders" ? (
        <div className="admin-orders">
          {orders.length ? (
            orders.map((o) => (
              <section className="panel admin-order" key={o._id}>
                <div>
                  <strong>#{o._id.slice(-8).toUpperCase()}</strong>
                  <p>
                    {o.user?.name || "Customer"} · {o.user?.email}
                  </p>
                  <small>
                    {o.items.map((i) => `${i.name} × ${i.quantity}`).join(", ")}
                  </small>
                  <p>
                    {o.address.line}, {o.address.city} · {o.address.phone}
                  </p>
                </div>
                <div className="admin-order-right">
                  <strong>{money(o.total)}</strong>
                  <span className="status">
                    {o.paymentStatus === "paid" ? o.status : "Unpaid"}
                  </span>
                  <small>
                    {o.paymentMethod === "demo"
                      ? "Demo · no charge"
                      : "Razorpay"}
                  </small>
                  {o.paymentStatus === "paid" && o.status !== "delivered" && (
                    <button
                      className="button primary"
                      onClick={() => status(o)}
                    >
                      {o.status === "placed"
                        ? "Mark shipped"
                        : "Mark delivered"}
                    </button>
                  )}
                </div>
              </section>
            ))
          ) : (
            <Empty
              title="No orders to manage"
              detail="Customer orders will appear here."
            />
          )}
        </div>
      ) : (
        <div className="admin-products">
          {products.map((p) => (
            <section className="panel admin-product" key={p._id}>
              <Image src={p.images[0]} name={p.name} />
              <div>
                <strong>{p.name}</strong>
                <p>
                  {money(p.price)} · {p.stock} in stock
                </p>
              </div>
              <div className="admin-product-actions">
                <button
                  className="button secondary"
                  onClick={() => setEditing(p)}
                >
                  Edit
                </button>
                <button
                  className="icon-danger"
                  aria-label={"Delete " + p.name}
                  onClick={() => remove(p)}
                >
                  <Trash2 size={19} />
                </button>
              </div>
            </section>
          ))}
        </div>
      )}
      <p className="muted small">
        Dashboard shows the latest 200 orders. Deleting a product archives it;
        order records stay intact.
      </p>
    </div>
  );
}
