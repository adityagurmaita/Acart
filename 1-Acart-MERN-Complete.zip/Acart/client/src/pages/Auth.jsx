import React, { useState, useEffect, createContext, useContext } from "react";
import {
  Routes,
  Route,
  Link,
  useNavigate,
  useSearchParams,
  useParams,
} from "react-router-dom";
import {
  Search,
  ShoppingCart,
  UserRound,
  ChevronDown,
  Package,
  ShieldCheck,
  Truck,
  ArrowRight,
  Headphones,
  Watch,
  Keyboard,
  Camera,
  Plug,
  Plus,
  Minus,
  Trash2,
  LogOut,
  Check,
  Star,
  LayoutDashboard,
  Menu,
  X,
} from "lucide-react";
import { api, money, rating } from "../api";
import { useStore, categories } from "../store";
import { Empty, ErrorBox, Image, Summary, Gate } from "../components/shared";
export default function Auth() {
  const { setUser, user } = useStore(),
    nav = useNavigate(),
    [params] = useSearchParams();
  const [signup, setSignup] = useState(false),
    [busy, setBusy] = useState(false),
    [error, setError] = useState("");
  const next =
    params.get("next")?.startsWith("/") && !params.get("next").startsWith("//")
      ? params.get("next")
      : "/";
  async function submit(e) {
    e.preventDefault();
    setBusy(true);
    setError("");
    const f = new FormData(e.target);
    try {
      const u = await api("/auth/" + (signup ? "signup" : "login"), {
        method: "POST",
        body: JSON.stringify(Object.fromEntries(f)),
      });
      setUser(u);
      nav(next);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }
  if (user)
    return (
      <div className="container">
        <Empty
          title={"Welcome, " + user.name}
          detail="You're already signed in."
        />
      </div>
    );
  return (
    <div className="container">
      <section className="auth panel">
        <div className="auth-intro">
          <span className="eyebrow">YOUR EVERYDAY UPGRADE</span>
          <h1>{signup ? "A fresh start." : "Welcome back."}</h1>
          <p>
            Your favourites, your orders, your store.
            <br />
            All in one place.
          </p>
          <ShoppingCart size={100} strokeWidth={1} />
        </div>
        <form onSubmit={submit}>
          <h2>{signup ? "Create an account" : "Sign in to Acart"}</h2>
          <ErrorBox message={error} />
          {signup && (
            <label>
              Full name
              <input
                name="name"
                autoComplete="name"
                required
                minLength={2}
                maxLength={60}
              />
            </label>
          )}
          <label>
            Email address
            <input name="email" type="email" autoComplete="email" required />
          </label>
          <label>
            Password
            <input
              name="password"
              type="password"
              autoComplete={signup ? "new-password" : "current-password"}
              required
              minLength={signup ? 10 : 1}
              maxLength={72}
            />
          </label>
          {signup && <small>Use at least 10 characters.</small>}
          <button className="button orange full" disabled={busy}>
            {busy ? "Please wait..." : signup ? "Create account" : "Sign in"}
          </button>
          <button
            type="button"
            className="auth-toggle"
            onClick={() => {
              setSignup(!signup);
              setError("");
            }}
          >
            {signup
              ? "Already have an account? Sign in"
              : "New here? Create an account"}
          </button>
          <p className="muted small">
            Your password is hashed. Your session stays in an HTTP-only cookie.
          </p>
        </form>
      </section>
    </div>
  );
}
