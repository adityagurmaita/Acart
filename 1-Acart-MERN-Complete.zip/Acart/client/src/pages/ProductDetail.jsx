import React, { useState, useEffect, createContext, useContext } from "react";
import {
  Routes,
  Route,
  Link,
  useNavigate,
  useSearchParams,
  useParams,
} from "react-router-dom";
import {
  Search,
  ShoppingCart,
  UserRound,
  ChevronDown,
  Package,
  ShieldCheck,
  Truck,
  ArrowRight,
  Headphones,
  Watch,
  Keyboard,
  Camera,
  Plug,
  Plus,
  Minus,
  Trash2,
  LogOut,
  Check,
  Star,
  LayoutDashboard,
  Menu,
  X,
} from "lucide-react";
import { api, money, rating } from "../api";
import { useStore, categories } from "../store";
import { Empty, ErrorBox, Image, Summary, Gate } from "../components/shared";
export default function ProductDetail() {
  const { id } = useParams(),
    { add, user, setToast } = useStore();
  const [p, setP] = useState(null),
    [error, setError] = useState(""),
    [index, setIndex] = useState(0),
    [busy, setBusy] = useState(false);
  useEffect(() => {
    setP(null);
    setError("");
    setIndex(0);
    api("/products/" + id)
      .then(setP)
      .catch((e) => setError(e.message));
  }, [id]);
  async function review(e) {
    e.preventDefault();
    setBusy(true);
    setError("");
    const f = new FormData(e.target);
    try {
      setP(
        await api("/products/" + id + "/reviews", {
          method: "POST",
          body: JSON.stringify({
            rating: Number(f.get("rating")),
            comment: f.get("comment"),
          }),
        }),
      );
      e.target.reset();
      setToast("Your review was added.");
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }
  if (error && !p)
    return (
      <div className="container">
        <ErrorBox message={error} />
      </div>
    );
  if (!p) return <div className="container loading">Loading product...</div>;
  return (
    <div className="container">
      <div className="breadcrumb">
        <Link to="/">Home</Link> / {p.category} / {p.name}
      </div>
      <section className="detail panel">
        <div className="detail-gallery">
          <div className="detail-image">
            <Image src={p.images[index]} name={p.name} />
          </div>
          {p.images.length > 1 && (
            <div className="thumbnails">
              {p.images.map((im, i) => (
                <button
                  key={i}
                  onClick={() => setIndex(i)}
                  aria-label={"View image " + (i + 1)}
                >
                  <Image src={im} name={p.name} />
                </button>
              ))}
            </div>
          )}
          <p className="photo-note">
            Illustrative photo. Demo product, not a branded listing.
          </p>
        </div>
        <div className="detail-copy">
          <span className="brand">
            {p.brand} · {p.category}
          </span>
          <h1>{p.name}</h1>
          <div className="rating-row">
            {rating(p) ? (
              <>
                <span className="rating">{rating(p)} ★</span>
                <span>{p.reviews.length} reviews</span>
              </>
            ) : (
              <span className="new-tag">Be the first to review</span>
            )}
          </div>
          <p className="special-price">Special price</p>
          <div className="detail-price">
            <strong>{money(p.price)}</strong>
            <del>{money(p.originalPrice)}</del>
            <span>
              {Math.round((1 - p.price / p.originalPrice) * 100)}% off
            </span>
          </div>
          <p className="muted">Inclusive of all taxes</p>
          <p className="description">{p.description}</p>
          <ul className="features">
            {p.features.map((f) => (
              <li key={f}>
                <Check size={17} />
                {f}
              </li>
            ))}
          </ul>
          <div className="delivery-note">
            <Truck size={20} />
            {p.price >= 1999 ? "Free delivery" : "₹49 delivery"} · {p.stock}{" "}
            available
          </div>
          <div className="detail-actions">
            <button
              className="button primary"
              disabled={!p.stock}
              onClick={() => add(p)}
            >
              <ShoppingCart size={20} />
              Add to cart
            </button>
            <Link className="button orange" to="/cart">
              Go to cart <ArrowRight size={19} />
            </Link>
          </div>
          <p className="safe-note">
            <ShieldCheck size={15} />
            Secure checkout · Order status updates
          </p>
        </div>
      </section>
      <section className="panel review-section">
        <h2>Ratings & reviews</h2>
        {p.reviews.length ? (
          p.reviews.map((r) => (
            <article className="review" key={r._id}>
              <span className="rating">{r.rating} ★</span>
              <strong>{r.name}</strong>
              <p>{r.comment}</p>
              <small>{new Date(r.createdAt).toLocaleDateString("en-IN")}</small>
            </article>
          ))
        ) : (
          <p className="muted">No reviews yet. Tell us what you think.</p>
        )}
        <ErrorBox message={error} />
        {user ? (
          <form className="review-form" onSubmit={review}>
            <h3>Write a review</h3>
            <label>
              Rating
              <select name="rating" defaultValue="5">
                {[5, 4, 3, 2, 1].map((n) => (
                  <option key={n} value={n}>
                    {n} stars
                  </option>
                ))}
              </select>
            </label>
            <label>
              Your review
              <textarea
                name="comment"
                required
                minLength={5}
                maxLength={800}
                placeholder="What did you like about this product?"
              />
            </label>
            <button className="button primary" disabled={busy}>
              {busy ? "Submitting..." : "Submit review"}
            </button>
          </form>
        ) : (
          <Link className="text-link" to="/auth">
            Sign in to write a review
          </Link>
        )}
      </section>
    </div>
  );
}
