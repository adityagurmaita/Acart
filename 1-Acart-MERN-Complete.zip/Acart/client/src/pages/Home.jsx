import React, { useState, useEffect, createContext, useContext } from "react";
import {
  Routes,
  Route,
  Link,
  useNavigate,
  useSearchParams,
  useParams,
} from "react-router-dom";
import {
  Search,
  ShoppingCart,
  UserRound,
  ChevronDown,
  Package,
  ShieldCheck,
  Truck,
  ArrowRight,
  Headphones,
  Watch,
  Keyboard,
  Camera,
  Plug,
  Plus,
  Minus,
  Trash2,
  LogOut,
  Check,
  Star,
  LayoutDashboard,
  Menu,
  X,
} from "lucide-react";
import { api, money, rating } from "../api";
import { useStore, categories } from "../store";
import { Empty, ErrorBox, Image, Summary, Gate } from "../components/shared";
export default function Home() {
  const [params, setParams] = useSearchParams(),
    [products, setProducts] = useState([]),
    [loading, setLoading] = useState(true),
    [error, setError] = useState("");
  const search = params.get("search") || "",
    category = params.get("category") || "",
    sort = params.get("sort") || "";
  useEffect(() => {
    let active = true;
    setLoading(true);
    setError("");
    api("/products?" + params.toString())
      .then((d) => active && setProducts(d))
      .catch((e) => active && setError(e.message))
      .finally(() => active && setLoading(false));
    return () => {
      active = false;
    };
  }, [params]);
  const update = (k, v) => {
    const next = new URLSearchParams(params);
    v ? next.set(k, v) : next.delete(k);
    setParams(next);
  };
  return (
    <div className="container">
      <section className="hero">
        <div className="hero-copy">
          <span className="eyebrow">THE EVERYDAY TECH EDIT</span>
          <h1>
            Small upgrades.
            <br />
            Big difference.
          </h1>
          <p>
            From focused work to your favourite playlists.
            <br className="desktop" /> Find your next everyday essential.
          </p>
          <a className="button white" href="#products">
            Shop the collection <ArrowRight size={18} />
          </a>
          <div className="hero-fine">
            Thoughtfully selected · Seriously good value
          </div>
        </div>
        <div className="hero-visual">
          <img
            src="/images/headphones.jpg"
            alt="Illustrative over-ear headphones"
          />
          <span className="hero-pill">Sound on. World off.</span>
        </div>
      </section>
      <div className="benefits">
        <span>
          <Truck />
          Free shipping over ₹1,999
        </span>
        <span>
          <ShieldCheck />
          Secure checkout
        </span>
        <span>
          <Package />
          Track every order
        </span>
      </div>
      <section id="products" className="catalog">
        <div className="section-heading">
          <div>
            <span className="eyebrow dark">DISCOVER YOUR NEXT UPGRADE</span>
            <h2>
              {search
                ? 'Results for "' + search + '"'
                : category || "Deals worth a look"}
            </h2>
            <p>
              {loading
                ? "Loading products..."
                : `${products.length} products · Prices inclusive of taxes`}
            </p>
          </div>
          <label className="sort">
            Sort by
            <select
              value={sort}
              onChange={(e) => update("sort", e.target.value)}
            >
              <option value="">Featured</option>
              <option value="price_asc">Price: low to high</option>
              <option value="price_desc">Price: high to low</option>
              <option value="newest">Newest</option>
            </select>
          </label>
        </div>
        <div className="filter-chips">
          <button
            className={!category ? "active" : ""}
            onClick={() => update("category", "")}
          >
            All products
          </button>
          {categories.map((c) => (
            <button
              key={c}
              className={category === c ? "active" : ""}
              onClick={() => update("category", c)}
            >
              {c}
            </button>
          ))}
          {search && (
            <button onClick={() => update("search", "")}>
              Clear search <X size={14} />
            </button>
          )}
        </div>
        <ErrorBox message={error} />
        {loading ? (
          <div className="product-grid">
            {[1, 2, 3, 4].map((i) => (
              <div className="skeleton" key={i} />
            ))}
          </div>
        ) : products.length ? (
          <div className="product-grid">
            {products.map((p) => (
              <ProductCard p={p} key={p._id} />
            ))}
          </div>
        ) : (
          !error && (
            <Empty
              title="No matching products"
              detail="Try another search or clear your filters."
            />
          )
        )}
      </section>
      <section className="bottom-banner">
        <div>
          <h2>Your desk. Your soundtrack. Your world.</h2>
          <p>Find the little things that make your day better.</p>
        </div>
        <Link to="/?category=Accessories">
          Explore accessories <ArrowRight size={19} />
        </Link>
      </section>
    </div>
  );
}

function ProductCard({ p }) {
  const { add } = useStore();
  const r = rating(p);
  return (
    <article className="product-card">
      <Link to={"/product/" + p._id} className="product-image">
        <Image src={p.images[0]} name={p.name} loading="lazy" />
        <span className="offer-tag">
          {Math.round((1 - p.price / p.originalPrice) * 100)}% off
        </span>
      </Link>
      <div className="product-content">
        <span className="brand">
          {p.brand} / {p.category}
        </span>
        <Link className="product-name" to={"/product/" + p._id}>
          {p.name}
        </Link>
        <div className="rating-row">
          {r ? (
            <>
              <span className="rating">{r} ★</span>
              <span>({p.reviews.length})</span>
            </>
          ) : (
            <span className="new-tag">New arrival</span>
          )}
          <span className="stock">{p.stock ? "In stock" : "Sold out"}</span>
        </div>
        <div className="price-row">
          <strong>{money(p.price)}</strong>
          <del>{money(p.originalPrice)}</del>
        </div>
        <div className="card-bottom">
          <span>{p.price >= 1999 ? "Free delivery" : "Delivery ₹49"}</span>
          <button
            onClick={() => add(p)}
            disabled={!p.stock}
            aria-label={"Add " + p.name + " to cart"}
          >
            <Plus size={19} />
          </button>
        </div>
      </div>
    </article>
  );
}
