import { createContext, useContext } from "react";
export const Context = createContext();
export const useStore = () => useContext(Context);
export const categories = [
  "Audio",
  "Wearables",
  "Computing",
  "Cameras",
  "Accessories",
];
