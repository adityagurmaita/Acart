import React, { useState, useEffect, createContext, useContext } from "react";
import {
  Routes,
  Route,
  Link,
  useNavigate,
  useSearchParams,
  useParams,
} from "react-router-dom";
import {
  Search,
  ShoppingCart,
  UserRound,
  ChevronDown,
  Package,
  ShieldCheck,
  Truck,
  ArrowRight,
  Headphones,
  Watch,
  Keyboard,
  Camera,
  Plug,
  Plus,
  Minus,
  Trash2,
  LogOut,
  Check,
  Star,
  LayoutDashboard,
  Menu,
  X,
} from "lucide-react";
import { api, money, rating } from "./api";
import { Context, useStore, categories } from "./store";
import { Empty } from "./components/shared";
import Home from "./pages/Home";
import ProductDetail from "./pages/ProductDetail";
import Cart from "./pages/Cart";
import Auth from "./pages/Auth";
import Checkout from "./pages/Checkout";
import Orders from "./pages/Orders";
import Admin from "./pages/Admin";
const icons = [Headphones, Watch, Keyboard, Camera, Plug];
function App() {
  const [user, setUser] = useState(null),
    [ready, setReady] = useState(false),
    [config, setConfig] = useState({}),
    [cart, setCart] = useState(() => {
      try {
        const d = JSON.parse(localStorage.getItem("acart-cart") || "[]");
        return Array.isArray(d)
          ? d.filter(
              (i) => i._id && Number.isInteger(i.quantity) && i.quantity > 0,
            )
          : [];
      } catch {
        return [];
      }
    }),
    [toast, setToast] = useState("");
  useEffect(() => {
    api("/auth/me")
      .then(setUser)
      .catch(() => {})
      .finally(() => setReady(true));
    api("/config")
      .then(setConfig)
      .catch(() => {});
  }, []);
  useEffect(() => {
    localStorage.setItem("acart-cart", JSON.stringify(cart));
  }, [cart]);
  useEffect(() => {
    if (toast) {
      const t = setTimeout(() => setToast(""), 3500);
      return () => clearTimeout(t);
    }
  }, [toast]);
  const add = (p) => {
    setCart((prev) => {
      const i = prev.find((x) => x._id === p._id);
      if ((i?.quantity || 0) >= Math.min(p.stock, 10)) {
        setToast("Maximum available quantity reached.");
        return prev;
      }
      return i
        ? prev.map((x) =>
            x._id === p._id ? { ...x, quantity: x.quantity + 1 } : x,
          )
        : [...prev, { ...p, quantity: 1 }];
    });
    setToast("Added to your cart");
  };
  return (
    <Context.Provider
      value={{ user, setUser, ready, config, cart, setCart, add, setToast }}
    >
      <Header />
      <main>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/product/:id" element={<ProductDetail />} />
          <Route path="/cart" element={<Cart />} />
          <Route path="/auth" element={<Auth />} />
          <Route path="/checkout" element={<Checkout />} />
          <Route path="/orders" element={<Orders />} />
          <Route path="/admin" element={<Admin />} />
          <Route
            path="*"
            element={
              <Empty
                title="Page not found"
                detail="Let's get you back to the store."
              />
            }
          />
        </Routes>
      </main>
      <Footer />
      {toast && (
        <div role="status" className="toast">
          <Check size={18} />
          {toast}
        </div>
      )}
    </Context.Provider>
  );
}
function Header() {
  const { user, setUser, cart, setToast } = useStore();
  const [q, setQ] = useState(""),
    [open, setOpen] = useState(false);
  const nav = useNavigate();
  return (
    <>
      <div className="topnote">
        Portfolio store · Illustrative products · No real fulfilment
      </div>
      <header>
        <div className="header-inner">
          <Link className="logo" to="/">
            acart
            <span>
              Everyday, upgraded <b>✦</b>
            </span>
          </Link>
          <form
            className="search"
            onSubmit={(e) => {
              e.preventDefault();
              nav("/?search=" + encodeURIComponent(q));
            }}
          >
            <Search size={21} />
            <input
              aria-label="Search products"
              placeholder="Search for products, brands and more"
              value={q}
              onChange={(e) => setQ(e.target.value)}
            />
            <button aria-label="Submit search" type="submit">
              <ArrowRight size={20} />
            </button>
          </form>
          <nav className={open ? "header-nav open" : "header-nav"}>
            {user ? (
              <>
                <Link to="/orders">
                  <Package size={19} />
                  My orders
                </Link>
                {user.role === "admin" && (
                  <Link to="/admin">
                    <LayoutDashboard size={19} />
                    Admin
                  </Link>
                )}
                <button
                  onClick={async () => {
                    try {
                      await api("/auth/logout", { method: "POST" });
                      setUser(null);
                      nav("/");
                    } catch (e) {
                      setToast(e.message);
                    }
                  }}
                  aria-label="Sign out"
                >
                  <LogOut size={18} />
                </button>
              </>
            ) : (
              <Link to="/auth" className="login-link">
                <UserRound size={19} />
                Login
              </Link>
            )}
            <Link to="/cart">
              <ShoppingCart size={22} />
              Cart
              {cart.length > 0 && (
                <span className="cart-count">
                  {cart.reduce((s, i) => s + i.quantity, 0)}
                </span>
              )}
            </Link>
          </nav>
          <button
            className="menu-button"
            aria-label="Toggle navigation"
            onClick={() => setOpen(!open)}
          >
            {open ? <X /> : <Menu />}
          </button>
        </div>
      </header>
      <div className="category-nav">
        <Link to="/" className="all-category">
          All products
        </Link>
        {categories.map((c, i) => {
          const Icon = icons[i];
          return (
            <Link to={"/?category=" + c} key={c}>
              <Icon size={22} />
              {c}
              <ChevronDown size={13} />
            </Link>
          );
        })}
      </div>
    </>
  );
}
function Footer() {
  return (
    <footer>
      <div className="container footer-grid">
        <div>
          <strong className="footer-logo">acart</strong>
          <p>Better tech for your everyday.</p>
          <small>
            A MERN portfolio project. Sample brands, specifications and prices
            are fictional. Photos are illustrative.
          </small>
        </div>
        <div>
          <strong>Explore</strong>
          <Link to="/">Shop products</Link>
          <Link to="/cart">Your cart</Link>
          <Link to="/orders">Your orders</Link>
        </div>
        <div>
          <strong>Built to work</strong>
          <p>Secure account access</p>
          <p>Razorpay-ready checkout</p>
          <p>Responsive by design</p>
        </div>
      </div>
      <div className="footer-bottom">
        Acart Store · React / Express / MongoDB / Node.js
      </div>
    </footer>
  );
}
export default App;
