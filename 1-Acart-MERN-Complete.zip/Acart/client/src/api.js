export async function api(path, options = {}) {
  const r = await fetch((import.meta.env.VITE_API_URL || "") + "/api" + path, {
    credentials: "include",
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  const data = await r.json();
  if (!r.ok) throw new Error(data.message || "Request failed.");
  return data;
}
export const money = (n) =>
  new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(n);
export const rating = (p) =>
  p.reviews.length
    ? (p.reviews.reduce((a, r) => a + r.rating, 0) / p.reviews.length).toFixed(
        1,
      )
    : null;
