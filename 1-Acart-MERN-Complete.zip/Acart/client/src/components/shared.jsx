import React, { useState, useEffect, createContext, useContext } from "react";
import {
  Routes,
  Route,
  Link,
  useNavigate,
  useSearchParams,
  useParams,
} from "react-router-dom";
import {
  Search,
  ShoppingCart,
  UserRound,
  ChevronDown,
  Package,
  ShieldCheck,
  Truck,
  ArrowRight,
  Headphones,
  Watch,
  Keyboard,
  Camera,
  Plug,
  Plus,
  Minus,
  Trash2,
  LogOut,
  Check,
  Star,
  LayoutDashboard,
  Menu,
  X,
} from "lucide-react";
import { api, money, rating } from "../api";
import { useStore, categories } from "../store";
export function Empty({ title, detail }) {
  return (
    <section className="empty panel">
      <Package size={48} />
      <h2>{title}</h2>
      <p>{detail}</p>
      <Link className="button primary" to="/">
        Explore products
      </Link>
    </section>
  );
}

export function ErrorBox({ message }) {
  return message ? (
    <div className="error" role="alert">
      {message}
    </div>
  ) : null;
}

export function Image({ src, name, ...props }) {
  return (
    <img
      src={src}
      alt={name}
      onError={(e) => {
        e.currentTarget.style.opacity = ".15";
      }}
      {...props}
    />
  );
}

export function Summary({ total, count, children }) {
  const shipping = total >= 1999 ? 0 : 49;
  return (
    <aside className="panel summary">
      <h3>Price details</h3>
      <div>
        <span>Price ({count} items)</span>
        <span>{money(total)}</span>
      </div>
      <div>
        <span>Delivery charges</span>
        <span className="green">{shipping ? money(shipping) : "FREE"}</span>
      </div>
      <div className="summary-total">
        <strong>Total amount</strong>
        <strong>{money(total + shipping)}</strong>
      </div>
      <p>Prices inclusive of taxes. No hidden fees.</p>
      {children}
    </aside>
  );
}

export function Gate({ admin = false, children }) {
  const { user, ready } = useStore();
  if (!ready) return <div className="loading">Loading account...</div>;
  if (!user)
    return (
      <div className="container">
        <section className="empty panel">
          <UserRound size={45} />
          <h2>Sign in to continue</h2>
          <Link
            className="button primary"
            to={
              "/auth?next=" +
              encodeURIComponent(admin ? "/admin" : location.pathname)
            }
          >
            Sign in
          </Link>
        </section>
      </div>
    );
  if (admin && user.role !== "admin")
    return (
      <div className="container">
        <Empty
          title="Admin access only"
          detail="This account does not have store management access."
        />
      </div>
    );
  return children;
}
