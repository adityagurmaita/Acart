# Deploy Acart with one website link

Recommended: one Node web service serves both React and Express, with MongoDB Atlas for storage. No accounts or services have been created for you. Deployment is a separate step; approve any provider costs first. Do not assume a free plan is suitable for a real shop.

## 1. Put the source in a repository

Extract the ZIP and upload the **source files**, not the ZIP itself, to a new private GitHub repository. Exclude `.env`, `node_modules`, and test account data. The included `.gitignore` already excludes sensitive/runtime files.

On a phone, GitHub's multi-folder source upload is awkward. Ask for help uploading this source or use a browser-based development workspace. Do not upload only the ZIP and expect Render to run it. Once the source repository exists, the remaining dashboard setup can be done in your mobile browser (Desktop site mode may help).

## 2. Create a MongoDB Atlas database

1. Open the official guide: https://www.mongodb.com/docs/atlas/tutorial/deploy-free-tier-cluster/
2. Create an account and project, then a Free cluster if the option is available and suits the project.
3. Create a database user with a strong password. This is different from your Atlas login.
4. Configure Network Access to allow your hosting service's outbound IP ranges. Render shows these in its dashboard. Prefer those ranges; avoid opening the database to all IPs for a public shop.
5. Choose Connect → Drivers → Node.js. Copy the connection string into the hosting environment as `MONGODB_URI`. Use `/acart` as the database name and percent-encode special password characters. Keep credentials private.

Atlas supports the transactions used by this project. Do not connect to a standalone MongoDB instance.

## 3. Create a Render Web Service

Official guide: https://render.com/docs/deploy-node-express-app

1. Sign in to Render, choose New → Web Service, and connect the Acart source repository.
2. Choose Node runtime. Keep the repository root directory (do not select `client` or `server`).
3. Set **Build Command**:
   ```text
   npm ci --include=dev && npm run build
   ```
4. Set **Start Command** for the initial setup:
   ```text
   npm run seed && npm start
   ```
   Seed is non-destructive. After the first successful setup, you can change this to `npm start` and remove `ADMIN_PASSWORD` from the environment.
5. Choose a plan after reviewing its current price/limits. If a free plan is offered, treat it as a portfolio/demo plan; it may sleep and take time to start. No purchase is authorised by these instructions.
6. Add environment variables:
   - `NODE_ENV=production`
   - `MONGODB_URI` = your Atlas connection string
   - `JWT_SECRET` = at least 32 random characters
   - `ADMIN_EMAIL` = your admin email
   - `ADMIN_PASSWORD` = a password of at least 10 characters (only used at initial seed)
   - `ENABLE_DEMO_PAYMENTS=true` for the portfolio demo
   - `CLIENT_URL` = the **exact** HTTPS URL Render gives your service (no trailing slash)
7. Deploy. If Render does not show the assigned service URL until creation, create the service, then set `CLIENT_URL` to that actual URL and redeploy. Do not guess a domain.
8. Open the actual service URL, create a customer account, complete a no-charge demo order, then sign in as admin and mark it shipped/delivered.
9. Test on your Android phone. Open `/api/health`; the response should say `ok: true` and `database: connected`.

To use a custom domain later, also update `CLIENT_URL` to its exact HTTPS origin. Keep the frontend and API on the same domain.

## 4. Enable Razorpay test checkout

Add your test key ID, test secret and webhook secret. Follow the README's payment steps, configure a signed `payment.captured` webhook using the actual deployment URL, and confirm the entire test payment flow. Only then plan a live-payment launch.

## Troubleshooting

- **"JWT_SECRET must contain..."**: secret is missing or too short.
- **MongoDB connect timeout**: check Atlas Network Access and the database username/password in the URI.
- **Transaction error**: use Atlas or a replica set, not standalone MongoDB.
- **Signup/admin access fails**: check seed logs and the chosen admin email/password. Customer signup cannot create an admin.
- **"Request origin is not allowed"**: `CLIENT_URL` must exactly match the browser's HTTPS origin without a trailing slash.
- **App page loads but no products**: run the seed step and check API logs.
- **Payments are not configured**: enable demo checkout for portfolio testing or configure your own Razorpay keys.
- **Web service exits**: check provider logs. Do not paste database/password/API secrets into chat or screenshots.

## Provider references checked during preparation

Render's Node/Express deployment guide and MongoDB's Free cluster guide were read when preparing this package. Plan prices, UI labels and availability may change; check the dashboards at deployment time.
