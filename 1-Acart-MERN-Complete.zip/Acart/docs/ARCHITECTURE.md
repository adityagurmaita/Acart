# Architecture and interview guide

## Data flow

React pages → fetch API client → Express middleware/routes → Mongoose → MongoDB replica set.

Production uses one origin: Express serves `/api/*` and the built React files. In development, Vite proxies `/api` to Express. Authentication uses a signed JWT in an HTTP-only cookie; the frontend stores no authentication token. The cart alone is persisted in browser local storage.

## Main models

- **User**: name, unique email, hashed password, customer/admin role.
- **Product**: catalogue details, images, price, inventory, reviews, archive flag.
- **Order**: owner, immutable checkout line items/prices, address, totals, payment method/status, gateway IDs, delivery status/history.

## Checkout

1. The client sends only product IDs, integer quantities and address information.
2. The server retrieves current products, checks stock and calculates prices/shipping.
3. Demo checkout performs inventory changes and payment-state changes together in a MongoDB transaction.
4. Razorpay checkout first creates a pending internal order and a gateway order.
5. Callback confirmation validates the HMAC signature and retrieves the payment from the gateway. Captured status, INR amount and order ID must match.
6. A signed `payment.captured` webhook provides a second completion path.
7. Settlement is idempotent: a previously paid order is not deducted from stock twice.
8. Admin can ship only paid orders, and transitions must be placed → shipped → delivered.

The gateway HTTP boundary is injectable for tests. Tests use controlled responses, not a real payment account. Production uses authenticated Razorpay REST API requests with timeouts.

## Important choices to explain

- **Transactions** prevent stock/order partial writes and concurrent overselling.
- **Server totals** stop client price tampering.
- **HTTP-only cookies** reduce token exposure to JavaScript, but do not replace an XSS/security review.
- **Role checks on the API** protect admin routes, not just hidden UI buttons.
- **Archived products** preserve historic order records.
- **Same-origin deployment** simplifies cookies and CORS.
- **Signed webhooks** prevent trusting arbitrary payment notifications.

## API map

| Method | Path | Access |
|---|---|---|
| GET | `/api/health`, `/api/config` | Public |
| POST | `/api/auth/signup`, `/api/auth/login`, `/api/auth/logout` | Public / session |
| GET | `/api/auth/me` | Signed in |
| GET | `/api/products`, `/api/products/:id` | Public |
| POST | `/api/products/:id/reviews` | Signed in |
| POST | `/api/orders` | Signed in |
| GET | `/api/orders` | Current user's orders |
| POST | `/api/orders/:id/verify` | Order owner |
| POST | `/api/payments/webhook` | Valid gateway signature |
| GET | `/api/admin/orders` | Admin |
| PATCH | `/api/admin/orders/:id` | Admin |
| POST | `/api/admin/products` | Admin |
| PUT / DELETE | `/api/admin/products/:id` | Admin |

## Honest portfolio description

"Built a responsive MERN e-commerce application with role-based access, JWT cookie sessions, product CRUD, reviews, transactional inventory updates, Razorpay-ready checkout and order tracking. Verified the shopping/admin flow with browser tests and backend integration tests."

Do not claim real customers, processed revenue or production deployment until those are true. Real gateway end-to-end testing needs your own Razorpay test keys. This project is not a multi-seller marketplace, and does not contain every Flipkart function.
