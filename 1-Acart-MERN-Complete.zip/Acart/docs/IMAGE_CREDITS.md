# Illustrative photo sources

The catalogue uses stock photography, not images of actual Acart merchandise. Product names, brands, specifications, prices and inventory are demo data. Visible photos may show unrelated real brands. Do not imply sponsorship or affiliation when presenting this project.

Images are bundled so the store does not rely on external image requests at runtime. Source URLs fetched during preparation:

- Headphones: https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=900&q=85
- Watch: https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=900&q=85
- Keyboard: https://images.unsplash.com/photo-1587829741301-dc798b83add3?auto=format&fit=crop&w=900&q=85
- Speaker: https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?auto=format&fit=crop&w=900&q=85
- Mouse: https://images.unsplash.com/photo-1527814050087-3793815479db?auto=format&fit=crop&w=900&q=85
- Camera: https://images.unsplash.com/photo-1516035069371-29a1b244cc32?auto=format&fit=crop&w=900&q=85
- Accessories (illustrative tech arrangement): https://images.unsplash.com/photo-1624823183493-ed5832f48f18?auto=format&fit=crop&w=900&q=85
- Backpack: https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=900&q=85

Replace these with your own authorised merchandise images before using Acart for a real store.
